#include <iostream>

using namespace std;

int main(void) {
	int i,j,k;
	cout << "witamy w WSH";
	for(i=0;i<10;i++){
		j=i+10;
		k=i*j;
		cout << "Krok " << i << endl;
	}
	cout << "Koniec\n";
	return 0;
}
