#include <iostream>

using namespace std;

int main()
{
    cout<<"Witamy w WSH";

    return 0;
}

