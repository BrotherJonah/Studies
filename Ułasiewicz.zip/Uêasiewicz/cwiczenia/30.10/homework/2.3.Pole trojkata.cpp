#include <iostream>
#include <math.h>

using namespace std;

int main()
{
	float a,b,c,h,p,P;
	int liczba;
	
	char str[] = "Liczymy pole trojkata. \nWybierz sposob obliczenia:\n 1-Bok a i wysokosc:\n 2-wzor Harona (a,b,c)\n";
	
	cout << str;
	cin >> liczba;
	cout << "liczba " << liczba << endl;
	switch (liczba)
      {
         case 1:
            cout << "Podaj bok a: ";
            cin >> a;
            cout << "Podaj wysokosc: ";
            cin >> h;
            p = (1/2)*a*h;
            cout << "Pole trojkata wynosi: " << p;
            break;
         case 2:
            cout << "Podaj bok a: ";
            cin >> a;
            cout << "Podaj bok b: ";
            cin >> b;
            cout << "Podaj bok c: ";
            cin >> c;
            cout << a << " " << b << " " << c << endl;
            p = (a+b+c)/2;
            cout << p << endl;
            P = p*(p-a)*(p-b)*(p-c);
            cout << P << endl;
            P = sqrt(P);
            cout << "Pole trojkata wynosi: " << P;
            break;
      }
     	
    return 0;
}

