#include <iostream>
#include <math.h>

using namespace std;

int main()
{
	int x;
	char str[] = "Liczbe nieujemna, wymierna... Wpisz jeszcze raz";
	
	cout << "wpisz liczb� nieujemn� wymiern�";
    cin >> x;
    while (x <= 0){
    	cerr << "Error message : " << str << endl;
 		cin >> x;
	}
    
	cout << sqrt(x);
	
    return 0;
}

