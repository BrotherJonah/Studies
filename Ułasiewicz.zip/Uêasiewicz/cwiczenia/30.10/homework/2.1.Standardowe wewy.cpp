#include <iostream>

using namespace std;

int main()
{
	int i,j,k;
    cin >> i >> j >> k;
    
	cout << "i=" << i << ", " << "j=" << j << ", " << "k=" << k;

    return 0;
}

