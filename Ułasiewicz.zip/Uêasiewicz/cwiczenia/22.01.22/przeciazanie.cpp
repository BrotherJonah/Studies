//test przeci��ania operator�w
#include <iostream> 
#include <conio.h> 
using namespace std;
class Integer {
int i;
public:
Integer(int ii): i(ii) {printf("%i\n",i); }
Integer& operator+=(const Integer& rv) {
i += rv.i;
return *this;
}
const Integer operator+(const Integer& rv) {
return Integer(i+rv.i);
}
int get_i() { return i; }
};
int main(int argc, char *argv[])
{
Integer I(1), J(2), K(3);
I += J + K;
printf("%i\n",I.get_i());
}
