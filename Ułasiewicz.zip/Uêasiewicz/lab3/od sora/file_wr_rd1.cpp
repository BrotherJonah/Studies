// Przyklad zapisu i odczytu z pliku
#include <iostream>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#define MAXLEN 80
using namespace std;

typedef struct {
   char napis[MAXLEN];
   int liczba;	
} element_t;

int main(int argc, char *argv[]) {
  int wr,rd,res;
  element_t zelement;
  element_t oelement;
  strcpy(zelement.napis, "To jest napis");
  zelement.liczba = 123;
  cout << "Zapis " << endl;
  cout << zelement.napis << " " << zelement.liczba << endl;
  wr = open("plik.bin",O_WRONLY|O_CREAT,0666);
  if(wr < 0) {
  	perror("open - zapis");
  	return 0;
  }
  // Zapis do pliku 
  res = write(wr,&zelement,sizeof(zelement));
  if(res < 0) perror("zapis"); 
  else cout << "Zapisano: " << res << " bajtow" <<endl;
  close(wr);
  
  rd = open("plik.bin",O_RDONLY);
   if(wr < 0) {
  	perror("open - odczyt");
  	return 0;
  }
  res = read(rd,&oelement,sizeof(oelement));
  if(res < 0) perror("odczyt"); 
  else {
      cout << "Odczytano: " << res << " bajtow" <<endl;
      cout << oelement.napis << " " << oelement.liczba << endl;
  }
  close(rd);
  return rd;
}

