// Baza danych osob oparta na tablicy
// Nie ma obiekt�w
#include <iostream>
#include <string>
#include <conio.h>
#define MAXLEN 40

using namespace std;
const int MAX = 50;

typedef struct {
	char imie[MAXLEN];
	char nazwisko[MAXLEN];
	int pesel;
} osoba_t;

osoba_t tab[MAX]; // Tablica zawierajaca struktury typu osoba_t
int lelem = 0;    // aktualna liczba elementow tablicy
int koniec = 0;    // pozycja na ktorej wstawic nastepny element

int   wczytaj_osobe(osoba_t* osoba);
int   dodaj_osobe(osoba_t* osoba);
int   szukaj_osobe(int pesel, osoba_t* osoba);
void  wyswietl_osobe(osoba_t* osoba);
void  wyswietl_liste(osoba_t tab[]);
int   usun_osobe(int pesel);
int menu(void);


class Osoba {
public:
	string imie, nazwisko;
	int pesel;

	Osoba(string im, string nazw, int pes) {
		imie = im;
		nazwisko = nazw;
		pesel = pes;
	}

	Osoba() {
		imie = "";;
		nazwisko = "";
		pesel = 0;
	}

	wczytaj() {
		cout << "Podaj imie: ";
		cin >> imie;
		cout << "Podaj nazwisko: ";
		cin >> nazwisko;
		cout << "Podaj pesel: ";
		cin >> pesel;
	}

	wyswietl() {
		cout << "Imie: " << imie;
		cout << "Nazwisko: " << nazwisko;
		cout << "Pesel: " << pesel;
	}

	int daj_pesel() {
		cout << "Pesel: " << pesel;
		return pesel;
	}

	string daj_nazwisko() {
		cout << "Nazwisko: " << nazwisko;
		return nazwisko;
	}

	string daj_imie() {
		cout << "Imie: " << imie;
		return imie;
	}
};

int main() {
	koniec = 0;
	lelem = 0;
	int pesel;
	int wybor;
	osoba_t osoba;
	cout << "Baza danych osob" << endl;
	/*
	osoba_t os1 = {"Adam","Kon",11};
	osoba_t os2 = {"wieslaw","Wilk",22};
	osoba_t os3 = {"Ewa","Koza",33};
	wczytaj_osobe(&osoba);
	wyswietl_osobe(&osoba);
	dodaj_osobe(&os1);
	dodaj_osobe(&os2);
	dodaj_osobe(&os3);
	wyswietl_liste(tab);
	szukaj_osobe(22,&osoba);
	usun_osobe(22);
	wyswietl_liste(tab);
	*/
	do {
		menu();
		wybor = getch();
		// cout << "wybrano " << wybor << endl;
		switch (wybor) {
		case '1': wczytaj_osobe(&osoba); dodaj_osobe(&osoba); break;
		case '2': wyswietl_liste(tab); break;
		case '3': cout << "Szukaj podaj pesel: ";
			cin >> pesel;
			szukaj_osobe(pesel, &osoba);
			break;
		case '4': cout << "Usun podaj pesel ";
			cin >> pesel;
			usun_osobe(pesel);
			break;
		case '5': cout << "Koniec" << endl;
			return 0;
		}
	} while (1);
	cout << "Koniec" << endl;
}


int dodaj_osobe(osoba_t* osoba) {
	int i = 0;
	int przed = 0;
	if (koniec == MAX) { // Tablica pelna
		cout << "Brak miejsca" << endl;
		return 0;
	}
	tab[koniec] = *osoba;
	cout << "dodano na pozycji:" << koniec << " " << osoba->nazwisko << endl;
	koniec++;
	lelem++;
	return koniec;
}


int wczytaj_osobe(osoba_t* osoba) {
	int cnt;
	cout << "Podaj imie: ";
	cin >> osoba->imie;
	cnt++;
	cout << "Podaj nazwisko: ";
	cin >> osoba->nazwisko;
	cnt++;
	cout << "Podaj pesel: ";
	cin >> osoba->pesel;
	cnt++;
	return cnt;
}

void wyswietl_osobe(osoba_t* osoba) {
	int cnt;
	cout << osoba->imie << " ";
	cout << osoba->nazwisko << " ";
	cout << osoba->pesel << endl;
	return;
}

void wyswietl_liste(osoba_t tab[]) {
	int i = 0;
	if (lelem == 0) {
		cout << "Lista jest pusta" << endl;
		return;
	}
	cout << "Wyswietl - koniec: " << koniec << endl;
	for (i = 0; i < koniec; i++) {
		wyswietl_osobe(&tab[i]);
	}
	return;
}

int szukaj_osobe(int pesel, osoba_t* osoba) {
	int i = 0;
	cout << "Szukaj, koniec: " << koniec << endl;
	for (i = 0; i < koniec; i++) {
		if (tab[i].pesel == pesel) {
			cout << "znaleziono poz: " << i << endl;
			*osoba = tab[i];
			wyswietl_osobe(&tab[i]);
			return i;
		}
	}
	return -1;
}

int usun_osobe(int pesel) {
	int i = 0;
	int found = -1;
	cout << "Usun, koniec: " << koniec << endl;
	// Najpierw szukamy osoby
	for (i = 0; i < koniec; i++) {
		if (tab[i].pesel == pesel) {
			cout << "znaleziono poz: " << i << endl;
			wyswietl_osobe(&tab[i]);
			found = i;
		}
	}
	// Sprawdzamy czy znaleziono ---
	if (found < 0) {
		cout << "Nie znaleziono osoby" << endl;
		return 0;
	}
	// Usuwamy osobe ---------------
	cout << "usuwamy z pozycji: " << found << endl;
	for (i = found; i < koniec; i++) {
		tab[i] = tab[i + 1];
	}
	koniec--;
	lelem--;
	return koniec;
}

int menu(void) {
	cout << "1 dodaj, 2 lista, 3 szukaj, 4 usun, 5 koniec\n";
}

